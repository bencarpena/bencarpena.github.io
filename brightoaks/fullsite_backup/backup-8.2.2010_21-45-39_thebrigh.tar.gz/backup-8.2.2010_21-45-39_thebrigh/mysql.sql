GRANT USAGE ON *.* TO 'thebrigh'@'localhost' IDENTIFIED BY PASSWORD '60c72aa02fd90ba6';
GRANT ALL PRIVILEGES ON `thebrigh`.* TO 'thebrigh'@'localhost';
GRANT ALL PRIVILEGES ON `thebrigh\_%`.* TO 'thebrigh'@'localhost';
