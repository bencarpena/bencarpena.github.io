-- MySQL dump 10.11
--
-- Host: localhost    Database: roundcube
-- ------------------------------------------------------
-- Server version	5.0.89-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(128) NOT NULL,
  `mail_host` varchar(128) NOT NULL,
  `alias` varchar(128) NOT NULL,
  `created` datetime NOT NULL default '1000-01-01 00:00:00',
  `last_login` datetime NOT NULL default '1000-01-01 00:00:00',
  `language` varchar(5) default NULL,
  `preferences` text,
  PRIMARY KEY  (`user_id`),
  KEY `username_index` (`username`),
  KEY `alias_index` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=1181 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--
-- WHERE:  user_id IN (1137,1136,1174)

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`user_id`, `username`, `mail_host`, `alias`, `created`, `last_login`, `language`, `preferences`) VALUES (1136,'lyn@thebrightoaks.com','localhost','','2010-07-06 20:17:27','2010-07-13 20:27:51','en_US','a:7:{s:16:\"message_sort_col\";s:2:\"to\";s:18:\"message_sort_order\";s:3:\"ASC\";s:12:\"logout_purge\";b:1;s:14:\"logout_expunge\";b:1;s:12:\"preview_pane\";b:1;s:17:\"check_all_folders\";b:1;s:8:\"timezone\";d:8;}'),(1137,'info@thebrightoaks.com','localhost','','2010-07-06 21:03:21','2010-07-06 21:03:21','en_US',NULL),(1174,'thebrigh','localhost','','2010-07-27 21:39:06','2010-07-27 21:39:06','en_US',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'roundcube'
--
DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-08-02 21:45:57
-- MySQL dump 10.11
--
-- Host: localhost    Database: roundcube
-- ------------------------------------------------------
-- Server version	5.0.89-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `messages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `message_id` int(11) unsigned NOT NULL auto_increment,
  `user_id` int(10) unsigned NOT NULL default '0',
  `del` tinyint(1) NOT NULL default '0',
  `cache_key` varchar(128) character set ascii NOT NULL,
  `created` datetime NOT NULL default '1000-01-01 00:00:00',
  `idx` int(11) unsigned NOT NULL default '0',
  `uid` int(11) unsigned NOT NULL default '0',
  `subject` varchar(255) NOT NULL,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `cc` varchar(255) NOT NULL,
  `date` datetime NOT NULL default '1000-01-01 00:00:00',
  `size` int(11) unsigned NOT NULL default '0',
  `headers` text NOT NULL,
  `structure` text,
  PRIMARY KEY  (`message_id`),
  UNIQUE KEY `uniqueness` (`user_id`,`cache_key`,`uid`),
  KEY `created_index` (`created`),
  CONSTRAINT `user_id_fk_messages` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=405224 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--
-- WHERE:  user_id IN (1137,1136,1174)

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'roundcube'
--
DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-08-02 21:45:57
-- MySQL dump 10.11
--
-- Host: localhost    Database: roundcube
-- ------------------------------------------------------
-- Server version	5.0.89-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `identities`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identities` (
  `identity_id` int(10) unsigned NOT NULL auto_increment,
  `del` tinyint(1) NOT NULL default '0',
  `standard` tinyint(1) NOT NULL default '0',
  `name` varchar(128) NOT NULL,
  `organization` varchar(128) NOT NULL default '',
  `email` varchar(128) NOT NULL,
  `reply-to` varchar(128) NOT NULL default '',
  `bcc` varchar(128) NOT NULL default '',
  `signature` text,
  `html_signature` tinyint(1) NOT NULL default '0',
  `user_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`identity_id`),
  KEY `user_id_fk_identities` (`user_id`),
  CONSTRAINT `user_id_fk_identities` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1200 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identities`
--
-- WHERE:  user_id IN (1137,1136,1174)

LOCK TABLES `identities` WRITE;
/*!40000 ALTER TABLE `identities` DISABLE KEYS */;
INSERT INTO `identities` (`identity_id`, `del`, `standard`, `name`, `organization`, `email`, `reply-to`, `bcc`, `signature`, `html_signature`, `user_id`) VALUES (1154,0,1,'Lyn','BrightOaks','lyn@thebrightoaks.com','lyn@thebrightoaks.com','webmaster@thebrightoaks.com','Lyn Carpena\r\nCFO\r\nBrightOaks',0,1136),(1155,0,1,'','','info@thebrightoaks.com','','','',0,1137),(1193,0,1,'thebrigh','','thebrigh@thebrightoaks.com','','','',0,1174);
/*!40000 ALTER TABLE `identities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'roundcube'
--
DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-08-02 21:45:57
-- MySQL dump 10.11
--
-- Host: localhost    Database: roundcube
-- ------------------------------------------------------
-- Server version	5.0.89-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contacts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `contact_id` int(10) unsigned NOT NULL auto_increment,
  `changed` datetime NOT NULL default '1000-01-01 00:00:00',
  `del` tinyint(1) NOT NULL default '0',
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `firstname` varchar(128) NOT NULL,
  `surname` varchar(128) NOT NULL,
  `vcard` text,
  `user_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`contact_id`),
  KEY `user_id_fk_contacts` (`user_id`),
  CONSTRAINT `user_id_fk_contacts` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2572 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--
-- WHERE:  user_id IN (1137,1136,1174)

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` (`contact_id`, `changed`, `del`, `name`, `email`, `firstname`, `surname`, `vcard`, `user_id`) VALUES (2512,'2010-07-06 20:26:26',1,'Loi','mistymathis228@gmail.com','Loi','Flores',NULL,1136),(2513,'2010-07-06 20:27:38',1,'Tine','tinetine868@gmail.com','Tine','Baterina',NULL,1136),(2514,'2010-07-06 20:28:27',1,'Tracy','tracy.carpena@gmail.com','Tracy','Carpena',NULL,1136),(2515,'2010-07-06 20:28:55',1,'Alou','alou_young28@yahoo.com','Alou','Young',NULL,1136),(2516,'2010-07-06 20:29:50',1,'Tracy','tracy.carpena@gmail.com','Tracy','Carpena',NULL,1136),(2517,'2010-07-06 20:30:39',1,'Tita Marie','mbaterina.dmd@gmail.com','Marie','Baterina',NULL,1136),(2518,'2010-07-06 20:32:03',0,'Ben - personal','bencarpena@gmail.com','Ben','Carpena',NULL,1136),(2519,'2010-07-13 20:52:49',0,'Ben - brightoaks','webmaster@thebrightoaks.com','Ben','Carpena',NULL,1136),(2520,'2010-07-06 20:33:50',1,'Johan - personal','johan@thebrightoaks.com','Johan','Carpena',NULL,1136),(2521,'2010-07-06 20:35:40',0,'Johan - personal','johancarpena@gmail.com','Johan','Carpena',NULL,1136),(2522,'2010-07-06 20:36:03',0,'Johan - brightoaks','johan@thebrightoaks.com','Johan','Carpena',NULL,1136),(2523,'2010-07-06 20:36:24',0,'Lyn - personal','lyncarpena@gmail.com','Lyn','Carpena',NULL,1136),(2524,'2010-07-06 20:36:53',0,'Alou','alou_young28@yahoo.com','Alou','Young',NULL,1136),(2525,'2010-07-06 20:37:44',0,'Dith','daryll_young28@yahoo.com.ph','Dith','Young',NULL,1136),(2526,'2010-07-06 20:38:41',0,'Loi','mistymathis228@gmail.com','Loi','Flores',NULL,1136),(2527,'2010-07-06 20:39:56',0,'Tine','tinetine868@gmail.com','Tine ','Baterina',NULL,1136),(2528,'2010-07-06 20:40:39',0,'Tita Marie','mbaterina.dmd@gmail.com','Marie','Baterina',NULL,1136),(2529,'2010-07-06 20:41:47',0,'Tracy','tracy.carpena@gmail.com','Tracy','Carpena',NULL,1136),(2530,'2010-07-06 20:42:30',0,'Mama Rancy','rancy_carpena@yahoo.com','Rancy','Carpena',NULL,1136),(2531,'2010-07-06 20:43:07',0,'Tita Jiji','jjcarpena@yahoo.com','Jiji','Carpena',NULL,1136),(2532,'2010-07-06 20:43:46',0,'Meanne','angela_91282@yahoo.com','Meanne','Galang',NULL,1136),(2533,'2010-07-06 20:44:54',0,'Miss Melissa Segui','lisa_segui@yahoo.com','Melissa ','Segui',NULL,1136),(2534,'2010-07-06 20:45:24',0,'Sr. Nilda','srnildah@yahoo.com','Sr. Nilda','Hechanova',NULL,1136),(2535,'2010-07-06 20:45:54',0,'Donny','donny_faj@yahoo.com','Donny','Fajutrao',NULL,1136),(2536,'2010-07-06 20:46:22',0,'CJA','cja.edu.ph@gmail.com','Child Jesus Academy','',NULL,1136);
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'roundcube'
--
DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-08-02 21:45:57
